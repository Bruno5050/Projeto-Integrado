﻿namespace sisRh
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TXTfun = new System.Windows.Forms.TextBox();
            this.TXTferias = new System.Windows.Forms.TextBox();
            this.TXTsalb = new System.Windows.Forms.TextBox();
            this.TXTbonus = new System.Windows.Forms.TextBox();
            this.TXTmeses = new System.Windows.Forms.TextBox();
            this.COMsetor = new System.Windows.Forms.ComboBox();
            this.BTNcal = new System.Windows.Forms.Button();
            this.BTNlimpar = new System.Windows.Forms.Button();
            this.BTNsair = new System.Windows.Forms.Button();
            this.LISTsaida = new System.Windows.Forms.ListBox();
            this.btnlimpal = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.combsex = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Funcionário:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Atuação: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salário: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(147, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Bônus recebido:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(23, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Meses trabalhados: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(154, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(77, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Dias de férias: ";
            // 
            // TXTfun
            // 
            this.TXTfun.Location = new System.Drawing.Point(27, 38);
            this.TXTfun.Name = "TXTfun";
            this.TXTfun.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.TXTfun.Size = new System.Drawing.Size(269, 20);
            this.TXTfun.TabIndex = 1;
            this.TXTfun.TextChanged += new System.EventHandler(this.TXTfun_TextChanged);
            // 
            // TXTferias
            // 
            this.TXTferias.Location = new System.Drawing.Point(162, 172);
            this.TXTferias.Name = "TXTferias";
            this.TXTferias.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TXTferias.Size = new System.Drawing.Size(98, 20);
            this.TXTferias.TabIndex = 5;
            this.TXTferias.Tag = "Dias de férias.";
            this.TXTferias.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TXTferias.TextChanged += new System.EventHandler(this.TXTx_TextChanged);
            this.TXTferias.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTx_KeyPress);
            // 
            // TXTsalb
            // 
            this.TXTsalb.Location = new System.Drawing.Point(35, 102);
            this.TXTsalb.Name = "TXTsalb";
            this.TXTsalb.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TXTsalb.Size = new System.Drawing.Size(101, 20);
            this.TXTsalb.TabIndex = 2;
            this.TXTsalb.Tag = "Salário Bruto.";
            this.TXTsalb.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TXTsalb.TextChanged += new System.EventHandler(this.TXTx_TextChanged);
            this.TXTsalb.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTx_KeyPress);
            // 
            // TXTbonus
            // 
            this.TXTbonus.Location = new System.Drawing.Point(162, 102);
            this.TXTbonus.Name = "TXTbonus";
            this.TXTbonus.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TXTbonus.Size = new System.Drawing.Size(110, 20);
            this.TXTbonus.TabIndex = 3;
            this.TXTbonus.Tag = "Bônus.";
            this.TXTbonus.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TXTbonus.TextChanged += new System.EventHandler(this.TXTx_TextChanged);
            this.TXTbonus.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTx_KeyPress);
            // 
            // TXTmeses
            // 
            this.TXTmeses.Location = new System.Drawing.Point(35, 172);
            this.TXTmeses.Name = "TXTmeses";
            this.TXTmeses.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TXTmeses.Size = new System.Drawing.Size(102, 20);
            this.TXTmeses.TabIndex = 4;
            this.TXTmeses.Tag = "Nº de meses trabalhados.";
            this.TXTmeses.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TXTmeses.TextChanged += new System.EventHandler(this.TXTx_TextChanged);
            this.TXTmeses.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTx_KeyPress);
            // 
            // COMsetor
            // 
            this.COMsetor.FormattingEnabled = true;
            this.COMsetor.Items.AddRange(new object[] {
            "Administração",
            "Business Partner",
            "Contabilidade",
            "Cordenador",
            "Produção ",
            "Tecnico de segurança",
            "Vendas"});
            this.COMsetor.Location = new System.Drawing.Point(88, 219);
            this.COMsetor.Name = "COMsetor";
            this.COMsetor.Size = new System.Drawing.Size(134, 21);
            this.COMsetor.TabIndex = 6;
            this.COMsetor.Tag = "";
            this.COMsetor.Text = "Area de atuação...";
            this.COMsetor.SelectedIndexChanged += new System.EventHandler(this.COMsetor_SelectedIndexChanged);
            // 
            // BTNcal
            // 
            this.BTNcal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTNcal.Image = ((System.Drawing.Image)(resources.GetObject("BTNcal.Image")));
            this.BTNcal.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BTNcal.Location = new System.Drawing.Point(12, 319);
            this.BTNcal.Name = "BTNcal";
            this.BTNcal.Size = new System.Drawing.Size(91, 46);
            this.BTNcal.TabIndex = 8;
            this.BTNcal.Text = "Calcular       ";
            this.BTNcal.UseVisualStyleBackColor = true;
            this.BTNcal.Click += new System.EventHandler(this.BTNcal_Click);
            // 
            // BTNlimpar
            // 
            this.BTNlimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTNlimpar.Image = ((System.Drawing.Image)(resources.GetObject("BTNlimpar.Image")));
            this.BTNlimpar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BTNlimpar.Location = new System.Drawing.Point(125, 319);
            this.BTNlimpar.Name = "BTNlimpar";
            this.BTNlimpar.Size = new System.Drawing.Size(88, 46);
            this.BTNlimpar.TabIndex = 9;
            this.BTNlimpar.Text = "Limpar          ";
            this.BTNlimpar.UseVisualStyleBackColor = true;
            this.BTNlimpar.Click += new System.EventHandler(this.BTNlimpar_Click);
            // 
            // BTNsair
            // 
            this.BTNsair.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTNsair.Image = ((System.Drawing.Image)(resources.GetObject("BTNsair.Image")));
            this.BTNsair.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.BTNsair.Location = new System.Drawing.Point(230, 319);
            this.BTNsair.Name = "BTNsair";
            this.BTNsair.Size = new System.Drawing.Size(89, 46);
            this.BTNsair.TabIndex = 10;
            this.BTNsair.Text = "Sair          ";
            this.BTNsair.UseVisualStyleBackColor = true;
            this.BTNsair.Click += new System.EventHandler(this.BTNsair_Click);
            // 
            // LISTsaida
            // 
            this.LISTsaida.FormattingEnabled = true;
            this.LISTsaida.Location = new System.Drawing.Point(334, 38);
            this.LISTsaida.Name = "LISTsaida";
            this.LISTsaida.Size = new System.Drawing.Size(470, 316);
            this.LISTsaida.TabIndex = 15;
            // 
            // btnlimpal
            // 
            this.btnlimpal.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnlimpal.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnlimpal.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnlimpal.Location = new System.Drawing.Point(706, 303);
            this.btnlimpal.Name = "btnlimpal";
            this.btnlimpal.Size = new System.Drawing.Size(75, 35);
            this.btnlimpal.TabIndex = 11;
            this.btnlimpal.Text = "Limpar";
            this.btnlimpal.UseVisualStyleBackColor = false;
            this.btnlimpal.Click += new System.EventHandler(this.btnlimpal_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(32, 269);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 18;
            this.label7.Text = "Sexo: ";
            // 
            // combsex
            // 
            this.combsex.FormattingEnabled = true;
            this.combsex.Items.AddRange(new object[] {
            "Não informar ",
            "Masculino",
            "Feminino"});
            this.combsex.Location = new System.Drawing.Point(88, 266);
            this.combsex.Name = "combsex";
            this.combsex.Size = new System.Drawing.Size(94, 21);
            this.combsex.TabIndex = 7;
            this.combsex.Text = "Selecionar...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(825, 405);
            this.Controls.Add(this.combsex);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.btnlimpal);
            this.Controls.Add(this.LISTsaida);
            this.Controls.Add(this.BTNsair);
            this.Controls.Add(this.BTNlimpar);
            this.Controls.Add(this.BTNcal);
            this.Controls.Add(this.COMsetor);
            this.Controls.Add(this.TXTmeses);
            this.Controls.Add(this.TXTbonus);
            this.Controls.Add(this.TXTsalb);
            this.Controls.Add(this.TXTferias);
            this.Controls.Add(this.TXTfun);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Sistema de Controle RH";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TXTfun;
        private System.Windows.Forms.TextBox TXTferias;
        private System.Windows.Forms.TextBox TXTsalb;
        private System.Windows.Forms.TextBox TXTbonus;
        private System.Windows.Forms.TextBox TXTmeses;
        private System.Windows.Forms.ComboBox COMsetor;
        private System.Windows.Forms.Button BTNcal;
        private System.Windows.Forms.Button BTNlimpar;
        private System.Windows.Forms.Button BTNsair;
        private System.Windows.Forms.ListBox LISTsaida;
        private System.Windows.Forms.Button btnlimpal;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox combsex;
    }
}

