﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sisRh
{   
    public partial class Form1 : Form
    {
        double basecal;
        public Form1()
        {
            InitializeComponent();
        }

        int errod;

        public void limpar()
        {
            TXTbonus.Clear();
            TXTferias.Clear();
            TXTfun.Clear();
            TXTmeses.Clear();
            TXTsalb.Clear();
            TXTfun.Focus();
            COMsetor.SelectedItem = null;
            COMsetor.Text = "Escolha o setor";
        }

        private void TXTx_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox x = (TextBox)sender;

            if ((!char.IsDigit(e.KeyChar)) && (e.KeyChar != 08) && 
                (e.KeyChar == ',' && (sender as TextBox).Text.IndexOf(',') > -1))
            {
                MessageBox.Show("Só é permitido informar valores numéricos no campo " + x.Tag, "Erro");
                errod = 1;
            }

        }

        private void TXTx_TextChanged(object sender, EventArgs e)
        {
            TextBox x = (TextBox)sender;

            if (errod == 1)
            {
                x.Clear();
                errod = 0;
            }
        }

        public void TXTlimp_TextChanged(object sender, EventArgs e)
        {
            limpar();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnlimpal.Visible = false;
        }

        private void BTNsair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja Finalizar ?", "Saída", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        public void BTNcal_Click(object sender, EventArgs e)
        {
            btnlimpal.Visible = true;

            
            string setor;
            setor = TXTfun.Text;



            double salb, bonus, inss, irrf, salliq, valor, diasf, meses;
            string aliquotainss, aliquotairrf, valordedução;

            try
            {
            diasf = double.Parse(TXTferias.Text);
            meses = double.Parse(TXTmeses.Text);
            salb = double.Parse(TXTsalb.Text);
            bonus = double.Parse(TXTbonus.Text);



                if ((salb > 0 && bonus > 0) && ((diasf >= 10) && (diasf <= 30) && (salb > 0)) && ((meses >= 1) && (meses <= 12)) && (COMsetor.SelectedItem != null))


                {

                    LISTsaida.Items.Add(new string('=', 200));
                    LISTsaida.Items.Add(string.Format("Funcionario: {0} {1} Setor: {2}  {1} Sexo: {3} ",
                                              setor, new string(' ', 15), COMsetor.SelectedItem.ToString(), combsex.SelectedItem.ToString()));
                    LISTsaida.Items.Add(new string('-', 200));
                    LISTsaida.Items.Add("Salario Mensal");


                    valor = salb + bonus;


                    if (valor >= 0 && valor <= 1659.38)
                    {
                        inss = Math.Round((valor * 0.08), 2);
                        basecal = valor - inss;
                        aliquotainss = "8%";


                        LISTsaida.Items.Add(string.Format("Salario bruto: R$ {0} {1} Bonus: R$ {2} {3} Valor total bruto: R$ {4}",
                                                salb.ToString(), new string(' ', 10), salb.ToString(), new string(' ', 14), valor.ToString()));
                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} Bonus: R$ {2} {3} Valor total Bruto: R$ {4}",
                                               aliquotainss.ToString(), new string(' ', 11), inss.ToString(), new string(' ', 9), basecal.ToString()));

                    }
                    else if (valor >= 1659.39 && valor <= 2765.66)
                    {
                        inss = Math.Round((valor * 0.09), 2);
                        basecal = valor - inss;
                        aliquotainss = "9%";



                        LISTsaida.Items.Add(string.Format("Salario bruto: R$ {0} {1} Bonus: R$ {2} {3} Valor total bruto: R$ {4}",
                                                salb.ToString(), new string(' ', 10), salb.ToString(), new string(' ', 14), valor.ToString()));
                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} Bonus: R$ {2} {3} Valor total Bruto: R$ {4}",
                                               aliquotainss.ToString(), new string(' ', 11), inss.ToString(), new string(' ', 9), basecal.ToString()));

                    }
                    else if (valor >= 2765.67 && valor <= 5531.31)
                    {
                        inss = Math.Round((valor * 0.11), 2);
                        basecal = valor - inss;
                        aliquotainss = "11%";



                        LISTsaida.Items.Add(string.Format("Salario bruto: R$ {0} {1} Bonus: R$ {2} {3} Valor total bruto: R$ {4}",
                                                salb.ToString(), new string(' ', 10), salb.ToString(), new string(' ', 14), valor.ToString()));
                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} Bonus: R$ {2} {3} Valor total Bruto: R$ {4}",
                                               aliquotainss.ToString(), new string(' ', 11), inss.ToString(), new string(' ', 9), basecal.ToString()));

                    }
                    else if (valor >= 5531.32)
                    {
                        inss = 608.44;
                        basecal = valor - inss;
                        aliquotainss = "608,44 R$";



                        LISTsaida.Items.Add(string.Format("Salario bruto: R$ {0} {1} Bonus: R$ {2} {3} Valor total bruto: R$ {4}",
                                                salb.ToString(), new string(' ', 10), salb.ToString(), new string(' ', 14), valor.ToString()));
                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} Bonus: R$ {2} {3} Valor total Bruto: R$ {4}",
                                                aliquotainss.ToString(), new string(' ', 11), inss.ToString(), new string(' ', 9), basecal.ToString()));
                    }

                    if (basecal >= 0 && basecal <= 1903.98)
                    {

                        salliq = basecal;
                        aliquotairrf = "0";
                        valordedução = "0";


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$  {2} Valor a Deduzir: R$  {3}",
                                               aliquotairrf, new string(' ', 14), new string(' ', 18), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 1903.99 && basecal <= 2826.65)
                    {
                        irrf = Math.Round((basecal * 0.075 - 142.80), 2);
                        aliquotairrf = "7,5%";
                        valordedução = "142,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3} Valor a Deduzir: R$  {4}",
                                               aliquotairrf, new string(' ', 14), irrf.ToString(), new string(' ', 18), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 2826.66 && basecal <= 3751.05)
                    {
                        irrf = Math.Round((basecal * 0.15 - 354.80), 2);
                        aliquotairrf = "15%";
                        valordedução = "354,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3} Valor a Deduzir: R$  {4}",
                                               aliquotairrf, new string(' ', 14), irrf.ToString(), new string(' ', 18), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 3751.06 && basecal <= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2250 - 636.13), 2);
                        aliquotairrf = "22,50%";
                        valordedução = "636,13";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3} Valor a Deduzir: R$  {4}",
                                               aliquotairrf, new string(' ', 14), irrf.ToString(), new string(' ', 18), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2750 - 869.36), 2);
                        aliquotairrf = "27,50%";
                        valordedução = "869,36";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3} Valor a Deduzir: R$  {4}",
                                               aliquotairrf, new string(' ', 14), irrf.ToString(), new string(' ', 18), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Salario Liquido: " + salliq.ToString());

                    }



                    LISTsaida.Items.Add(new string('-', 200));
                    LISTsaida.Items.Add("Ferias");


                    valor = Math.Round(((salb * diasf) / 30), 2);

                    if (valor >= 0 && valor <= 1659.38)
                    {
                        inss = Math.Round((valor * 0.08), 2);
                        basecal = valor - inss;
                        aliquotainss = "8%";


                        LISTsaida.Items.Add(string.Format("Dias de Ferias: {0} {1} Valor total das Férias R$: {2}",
                                                diasf.ToString(), new string(' ', 46), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {3} Base Calculo: {4} ",
                                              aliquotainss.ToString(), new string(' ', 10), inss.ToString(), new string(' ', 16), basecal.ToString()));

                    }
                    else if (valor >= 1659.39 && valor <= 2765.66)
                    {
                        inss = Math.Round((valor * 0.09), 2);
                        basecal = valor - inss;
                        aliquotainss = "9%";



                        LISTsaida.Items.Add(string.Format("Dias de Ferias: {0} {1} Valor total das Férias R$: {2}",
                                                diasf.ToString(), new string(' ', 46), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {3} Base Calculo: {4} ",
                                              aliquotainss.ToString(), new string(' ', 10), inss.ToString(), new string(' ', 16), basecal.ToString()));
                    }
                    else if (valor >= 2765.67 && valor <= 5531.31)
                    {
                        inss = Math.Round((valor * 0.11), 2);
                        basecal = valor - inss;
                        aliquotainss = "11%";


                        LISTsaida.Items.Add(string.Format("Dias de Ferias: {0} {1} Valor total das Férias R$: {2}",
                                                diasf.ToString(), new string(' ', 46), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {3} Base Calculo: {4}",
                                              aliquotainss.ToString(), new string(' ', 10), inss.ToString(), new string(' ', 16), basecal.ToString()));
                    }
                    else if (valor >= 5531.32)
                    {
                        inss = 608.44;
                        basecal = valor - inss;
                        aliquotainss = "608,44 R$";



                        LISTsaida.Items.Add(string.Format("Dias de Ferias: {0} {1} Valor total das Férias R$: {2}",
                                                diasf.ToString(), new string(' ', 46), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {3} Base Calculo: {4}",
                                                aliquotainss.ToString(), new string(' ', 10), inss.ToString(), new string(' ', 16), basecal.ToString()));

                    }
                    if (basecal >= 0 && basecal <= 1903.98)
                    {

                        salliq = basecal;
                        aliquotairrf = "0";
                        valordedução = "0";


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ 0 {2}  Valor a Deduzir: R$ ",
                                                aliquotairrf, new string(' ', 12), new string(' ', 16), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Férias Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 1903.99 && basecal <= 2826.65)
                    {
                        irrf = Math.Round((basecal * 0.075 - 142.80), 2);
                        aliquotairrf = "7,5%";
                        valordedução = "142,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3}  Valor a Deduzir: R$ ",
                                                aliquotairrf, new string(' ', 12), irrf.ToString(), new string(' ', 16), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Férias Liquido: " + salliq.ToString());


                    }
                    else if (basecal >= 2826.66 && basecal <= 3751.05)
                    {
                        irrf = Math.Round((basecal * 0.15 - 354.80), 2);
                        aliquotairrf = "15%";
                        valordedução = "354,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3}  Valor a Deduzir: R$ ",
                                                aliquotairrf, new string(' ', 12), irrf.ToString(), new string(' ', 16), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Férias Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 3751.06 && basecal <= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2250 - 636.13), 2);
                        aliquotairrf = "22,50%";
                        valordedução = "636,13";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3}  Valor a Deduzir: R$ ",
                                                aliquotairrf, new string(' ', 12), irrf.ToString(), new string(' ', 16), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Férias Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2750 - 869.36), 2);
                        aliquotairrf = "27,50%";
                        valordedução = "869,36";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1} IRRF: R$ {2} {3}  Valor a Deduzir: R$ ",
                                                aliquotairrf, new string(' ', 12), irrf.ToString(), new string(' ', 16), valordedução));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("Férias Liquido: " + salliq.ToString());

                    }
                    //}
                    LISTsaida.Items.Add(new string('-', 200));
                    LISTsaida.Items.Add("13° Salario");



                    valor = Math.Round(((salb * meses) / 12), 2);
                    if (valor >= 0 && valor <= 1659.38)
                    {
                        inss = Math.Round((valor * 0.08), 2);
                        basecal = valor - inss;
                        aliquotainss = "8%";


                        LISTsaida.Items.Add(string.Format("Meses Trabalhados: : {0} {1} Valor total Trabalhado R$: {2}",
                                                          meses.ToString(), new string(' ', 38), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {4} Base Calculo {3}",
                                                   aliquotainss.ToString(), new string(' ', 12), inss.ToString(), basecal.ToString(), new string(' ', 16)));

                    }
                    else if (valor >= 1659.39 && valor <= 2765.66)
                    {
                        inss = Math.Round((valor * 0.09), 2);
                        basecal = valor - inss;
                        aliquotainss = "9%";



                        LISTsaida.Items.Add(string.Format("Meses Trabalhados: : {0} {1} Valor total Trabalhado R$: {2}",
                                                          meses.ToString(), new string(' ', 38), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {4} Base Calculo {3}",
                                                    aliquotainss.ToString(), new string(' ', 12), inss.ToString(), basecal.ToString(), new string(' ', 16)));
                    }
                    else if (valor >= 2765.67 && valor <= 5531.31)
                    {
                        inss = Math.Round((valor * 0.11), 2);
                        basecal = valor - inss;
                        aliquotainss = "11%";


                        LISTsaida.Items.Add(string.Format("Meses Trabalhados: : {0} {1} Valor total Trabalhado R$: {2}",
                                                          meses.ToString(), new string(' ', 38), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {4} Base Calculo {3}",
                                                   aliquotainss.ToString(), new string(' ', 12), inss.ToString(), basecal.ToString(), new string(' ', 16)));
                    }
                    else if (valor >= 5531.32)
                    {
                        inss = 608.44;
                        basecal = valor - inss;
                        aliquotainss = "608,44 R$";



                        LISTsaida.Items.Add(string.Format("Meses Trabalhados: : {0} {1} Valor total Trabalhado R$: {2}",
                                                          meses.ToString(), new string(' ', 38), valor.ToString()));

                        LISTsaida.Items.Add(string.Format("Aliquota INSS: {0} {1} INSS: {2} {4} Base Calculo {3}",
                                                   aliquotainss.ToString(), new string(' ', 12), inss.ToString(), basecal.ToString(), new string(' ', 16)));

                    }
                    if (basecal >= 0 && basecal <= 1903.98)
                    {

                        salliq = basecal;
                        aliquotairrf = "0";
                        valordedução = "0";


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1}IRRF R$: 0 {3} Valor a Deduzir R$: {2}",
                                                          aliquotairrf, new string(' ', 16), valordedução, new string(' ', 15)));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("13° Salario Liquido: " + salliq.ToString());


                    }
                    else if (basecal >= 1903.99 && basecal <= 2826.65)
                    {
                        irrf = Math.Round((basecal * 0.075 - 142.80), 2);
                        aliquotairrf = "7,5%";
                        valordedução = "142,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0}{1}IRRF R$: {3} {4} Valor a Deduzir R$: {2}",
                                                          aliquotairrf, new string(' ', 16), valordedução, irrf.ToString(), new string(' ', 15)));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("13° Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 2826.66 && basecal <= 3751.05)
                    {
                        irrf = Math.Round((basecal * 0.15 - 354.80), 2);
                        aliquotairrf = "15%";
                        valordedução = "354,80";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0}{1}IRRF R$: {3} {4} Valor a Deduzir R$: {2}",
                                                          aliquotairrf, new string(' ', 16), valordedução, irrf.ToString(), new string(' ', 15)));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("13° Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 3751.06 && basecal <= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2250 - 636.13), 2);
                        aliquotairrf = "22,50%";
                        valordedução = "636,13";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1}IRRF R$: {3} {4} Valor a Deduzir R$: {2}",
                                                         aliquotairrf, new string(' ', 16), valordedução, irrf.ToString(), new string(' ', 15)));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("13° Salario Liquido: " + salliq.ToString());

                    }
                    else if (basecal >= 4664.68)
                    {
                        irrf = Math.Round((basecal * 0.2750 - 869.36), 2);
                        aliquotairrf = "27,50%";
                        valordedução = "869,36";
                        salliq = basecal - irrf;


                        LISTsaida.Items.Add(string.Format("Aliquota IRRF: {0} {1}IRRF R$: {3} {4} Valor a Deduzir R$: {2}",
                                                         aliquotairrf, new string(' ', 16), valordedução, irrf.ToString(), new string(' ', 15)));
                        LISTsaida.Items.Add(new string(' ', 80));
                        LISTsaida.Items.Add("13° Salario Liquido: " + salliq.ToString());

                    }

                    LISTsaida.Items.Add(new string('=', 200));
                }
                else
                {
                    if (TXTfun.Text == "")
                    {
                        MessageBox.Show("Entre com o nome para proseguir");
                        TXTfun.Focus();

                    }

                    if (!(diasf >= 10 && diasf <= 30))
                    {
                        MessageBox.Show("A quantidade de dias que o funcionario teve de ferias deve ser um numero entre 10 e 30");
                    }

                    if (!(meses >= 1 && meses <= 12))
                    {
                        MessageBox.Show("Por favor, entre com uma valor que esteja entre 1 e 12");
                    }
                    if (COMsetor.SelectedItem == null)
                    {
                        MessageBox.Show("Escolha uma opção do Setor");
                    }
                    if (combsex .SelectedItem == null)
                    {
                        MessageBox.Show("Selecione um opção para Sexo");
                    }
                }

            }
            catch

            {
                btnlimpal.Visible = false;
                MessageBox.Show("Por favor, verifique se o formulario possui campos em branco.");
                
            }
        }
            private void TXTfun_TextChanged(object sender, EventArgs e)
        {

        }

        private void BTNlimpar_Click(object sender, EventArgs e)
        {
            TXTbonus.Text = "";
            TXTferias.Text = "";
            TXTfun.Text = "";
            TXTmeses.Text = "";
            TXTsalb.Text = "";
            TXTfun.Focus();
            combsex.Text = "Selecionar...";
            COMsetor.Text = "Area de Atuação...";
        }

        private void COMsetor_SelectedIndexChanged(object sender, EventArgs e)
        {
  
        }

        private void btnlimpal_Click(object sender, EventArgs e)
        {
            LISTsaida.Items.Clear();
            btnlimpal.Visible = false;           
            TXTfun.Focus();
        }
    }
}
   // }
//}
